window.addEventListener('load', function() {
    setTimeout(function() {
        // Redirigir a la página usar xd
        window.location.href = "index.php";
    }, 1500);   
});
