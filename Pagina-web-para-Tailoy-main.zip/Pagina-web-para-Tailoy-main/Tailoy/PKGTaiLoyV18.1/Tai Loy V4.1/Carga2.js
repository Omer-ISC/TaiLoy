window.addEventListener('load', function() {
    setTimeout(function() {
        // Redirigir a la página usar xd
        window.location.href = "iniciosesion.html";
    }, 1500);   
});
